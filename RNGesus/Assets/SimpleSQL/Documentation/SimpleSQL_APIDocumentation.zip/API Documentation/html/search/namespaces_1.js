var searchData=
[
  ['simplesql',['SimpleSQL',['../namespace_simple_s_q_l.html',1,'']]]
];
