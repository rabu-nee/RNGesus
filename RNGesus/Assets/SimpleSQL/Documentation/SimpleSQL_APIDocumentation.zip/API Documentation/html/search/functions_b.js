var searchData=
[
  ['update',['Update',['../class_simple_s_q_l_1_1_s_q_lite_connection.html#a7e9e38ad877a241931d12f48e3bc7763',1,'SimpleSQL::SQLiteConnection']]],
  ['updatetable',['UpdateTable',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#ab9502aca68f70b82b718b262fbb959d5',1,'SimpleSQL::SimpleSQLManager']]]
];
