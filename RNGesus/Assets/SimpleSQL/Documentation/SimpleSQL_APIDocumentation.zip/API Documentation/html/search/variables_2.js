var searchData=
[
  ['name',['name',['../class_simple_s_q_l_1_1_simple_data_column.html#ab67aadd0699c2a636d6152af2b0e7adf',1,'SimpleSQL::SimpleDataColumn']]]
];
