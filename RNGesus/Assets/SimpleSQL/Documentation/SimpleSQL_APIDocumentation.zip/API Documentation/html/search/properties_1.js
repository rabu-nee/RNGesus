var searchData=
[
  ['isintransaction',['IsInTransaction',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#a4951d3a85305644a9346538517ffe72d',1,'SimpleSQL.SimpleSQLManager.IsInTransaction()'],['../class_simple_s_q_l_1_1_s_q_lite_connection.html#aaa9e2502da433a9461ef3caa2592ce95',1,'SimpleSQL.SQLiteConnection.IsInTransaction()']]]
];
