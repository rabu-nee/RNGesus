var searchData=
[
  ['simpledatarow',['SimpleDataRow',['../class_simple_s_q_l_1_1_simple_data_row.html#a519f18411731c8eba1179efb646bf19e',1,'SimpleSQL::SimpleDataRow']]],
  ['sqliteconnection',['SQLiteConnection',['../class_simple_s_q_l_1_1_s_q_lite_connection.html#ac3582cb1028bb8efe93b6e4cadc515b5',1,'SimpleSQL::SQLiteConnection']]]
];
