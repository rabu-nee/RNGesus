var searchData=
[
  ['query',['Query',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#a21e47dddd18c202d54be87a516ebd146',1,'SimpleSQL.SimpleSQLManager.Query()'],['../class_simple_s_q_l_1_1_s_q_lite_connection.html#a7d628e1acb4b98ec5dc97a51157432f6',1,'SimpleSQL.SQLiteConnection.Query()']]],
  ['query_3c_20t_20_3e',['Query&lt; T &gt;',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#a1245a377e8ceeae8fc6be3dbc6e41473',1,'SimpleSQL.SimpleSQLManager.Query&lt; T &gt;()'],['../class_simple_s_q_l_1_1_s_q_lite_connection.html#a227351e3bf8d260029d39e31112ae214',1,'SimpleSQL.SQLiteConnection.Query&lt; T &gt;()']]],
  ['queryfirstrecord',['QueryFirstRecord',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#a9edc4ae461e95351ed4be70721887144',1,'SimpleSQL::SimpleSQLManager']]],
  ['queryfirstrecord_3c_20t_20_3e',['QueryFirstRecord&lt; T &gt;',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#a13e3805999c4a53391ce3b2937486504',1,'SimpleSQL::SimpleSQLManager']]],
  ['querygeneric',['QueryGeneric',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#a423aae7da00a392adb0290e7f53b7ce3',1,'SimpleSQL::SimpleSQLManager']]]
];
