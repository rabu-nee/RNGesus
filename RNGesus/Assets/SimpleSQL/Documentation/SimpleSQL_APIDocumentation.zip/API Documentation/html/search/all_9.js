var searchData=
[
  ['name',['name',['../class_simple_s_q_l_1_1_simple_data_column.html#ab67aadd0699c2a636d6152af2b0e7adf',1,'SimpleSQL::SimpleDataColumn']]],
  ['newrow',['NewRow',['../class_simple_s_q_l_1_1_simple_data_table.html#a5d179dc530d6bebf21cd37296d0f50a8',1,'SimpleSQL::SimpleDataTable']]],
  ['notnullattribute',['NotNullAttribute',['../class_extra___docs_1_1_attributes_1_1_not_null_attribute.html',1,'Extra_Docs.Attributes.NotNullAttribute'],['../class_simple_s_q_l_1_1_not_null_attribute.html',1,'SimpleSQL.NotNullAttribute']]]
];
