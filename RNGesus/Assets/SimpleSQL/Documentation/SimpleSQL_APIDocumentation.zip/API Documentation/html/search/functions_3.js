var searchData=
[
  ['execute',['Execute',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#afeb3af273c0ecac33d74b288468a2176',1,'SimpleSQL.SimpleSQLManager.Execute()'],['../class_simple_s_q_l_1_1_s_q_lite_connection.html#a01c9386f122d8fa47bfb2626a8f5320c',1,'SimpleSQL.SQLiteConnection.Execute()']]],
  ['executewithresult',['ExecuteWithResult',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#a8813351e61fac0b47608934fb37e21f7',1,'SimpleSQL::SimpleSQLManager']]]
];
