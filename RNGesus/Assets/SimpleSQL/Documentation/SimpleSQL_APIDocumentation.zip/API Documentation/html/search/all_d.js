var searchData=
[
  ['simpledatacolumn',['SimpleDataColumn',['../class_simple_s_q_l_1_1_simple_data_column.html',1,'SimpleSQL']]],
  ['simpledatarow',['SimpleDataRow',['../class_simple_s_q_l_1_1_simple_data_row.html',1,'SimpleSQL.SimpleDataRow'],['../class_simple_s_q_l_1_1_simple_data_row.html#a519f18411731c8eba1179efb646bf19e',1,'SimpleSQL.SimpleDataRow.SimpleDataRow()']]],
  ['simpledatatable',['SimpleDataTable',['../class_simple_s_q_l_1_1_simple_data_table.html',1,'SimpleSQL']]],
  ['simplesql',['SimpleSQL',['../namespace_simple_s_q_l.html',1,'']]],
  ['simplesqlmanager',['SimpleSQLManager',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html',1,'SimpleSQL']]],
  ['sqlitecommand',['SQLiteCommand',['../class_simple_s_q_l_1_1_s_q_lite_command.html',1,'SimpleSQL']]],
  ['sqliteconnection',['SQLiteConnection',['../class_simple_s_q_l_1_1_s_q_lite_connection.html',1,'SimpleSQL.SQLiteConnection'],['../class_simple_s_q_l_1_1_s_q_lite_connection.html#ac3582cb1028bb8efe93b6e4cadc515b5',1,'SimpleSQL.SQLiteConnection.SQLiteConnection()']]],
  ['sqliteexception',['SQLiteException',['../class_simple_s_q_l_1_1_s_q_lite_exception.html',1,'SimpleSQL']]]
];
