var searchData=
[
  ['begintransaction',['BeginTransaction',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#a90e6607c0afc265c543a6e9f3282c041',1,'SimpleSQL.SimpleSQLManager.BeginTransaction()'],['../class_simple_s_q_l_1_1_s_q_lite_connection.html#ae202801dc58d265131b4e735f6f533e9',1,'SimpleSQL.SQLiteConnection.BeginTransaction()']]]
];
