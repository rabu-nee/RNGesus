var searchData=
[
  ['fields',['fields',['../class_simple_s_q_l_1_1_simple_data_row.html#ad5cd7e1c0edf59bc7f9c8d52ffb06fe9',1,'SimpleSQL::SimpleDataRow']]]
];
