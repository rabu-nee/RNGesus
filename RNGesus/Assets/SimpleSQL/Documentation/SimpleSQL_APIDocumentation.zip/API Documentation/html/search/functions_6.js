var searchData=
[
  ['newrow',['NewRow',['../class_simple_s_q_l_1_1_simple_data_table.html#a5d179dc530d6bebf21cd37296d0f50a8',1,'SimpleSQL::SimpleDataTable']]]
];
