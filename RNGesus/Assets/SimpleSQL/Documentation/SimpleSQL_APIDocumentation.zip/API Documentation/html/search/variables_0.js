var searchData=
[
  ['columns',['columns',['../class_simple_s_q_l_1_1_simple_data_table.html#a04a5b68f1e89785240807c84e185cd4b',1,'SimpleSQL::SimpleDataTable']]]
];
