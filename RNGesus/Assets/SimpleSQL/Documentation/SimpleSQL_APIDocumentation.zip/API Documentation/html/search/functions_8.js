var searchData=
[
  ['rollback',['Rollback',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#a9d78c68abb2fc09c5f1520eab2016c0a',1,'SimpleSQL.SimpleSQLManager.Rollback()'],['../class_simple_s_q_l_1_1_s_q_lite_connection.html#afd530662b812414fc27c50adfa99a366',1,'SimpleSQL.SQLiteConnection.Rollback()']]],
  ['runintransaction',['RunInTransaction',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#a2a63de3e76a33e24d0ce829829ef7f91',1,'SimpleSQL.SimpleSQLManager.RunInTransaction()'],['../class_simple_s_q_l_1_1_s_q_lite_connection.html#aa9fc11ad3ea2787b3836bd04e2ac7387',1,'SimpleSQL.SQLiteConnection.RunInTransaction()']]]
];
