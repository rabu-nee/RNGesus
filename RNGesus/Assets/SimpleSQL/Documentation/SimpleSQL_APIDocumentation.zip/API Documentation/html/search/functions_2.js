var searchData=
[
  ['delete_3c_20t_20_3e',['Delete&lt; T &gt;',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#a58b8e4d7dacbfff312e18ad66bf60128',1,'SimpleSQL.SimpleSQLManager.Delete&lt; T &gt;()'],['../class_simple_s_q_l_1_1_s_q_lite_connection.html#a97afb017425454832ea3ce516e199293',1,'SimpleSQL.SQLiteConnection.Delete&lt; T &gt;()']]]
];
