var searchData=
[
  ['table_3c_20t_20_3e',['Table&lt; T &gt;',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#a385e0ff3ba827b9951a0c174c0364fe9',1,'SimpleSQL.SimpleSQLManager.Table&lt; T &gt;()'],['../class_simple_s_q_l_1_1_s_q_lite_connection.html#ab188c99ead2ccb939c26d418d3e0559b',1,'SimpleSQL.SQLiteConnection.Table&lt; T &gt;()']]]
];
