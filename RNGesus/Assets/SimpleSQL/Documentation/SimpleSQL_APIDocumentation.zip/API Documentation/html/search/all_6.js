var searchData=
[
  ['get_3c_20t_20_3e',['Get&lt; T &gt;',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#a7dff6dea36911f49c4ee91b8e2bebcdf',1,'SimpleSQL.SimpleSQLManager.Get&lt; T &gt;()'],['../class_simple_s_q_l_1_1_s_q_lite_connection.html#ae18e5552054edd7e73eee79f0528d82c',1,'SimpleSQL.SQLiteConnection.Get&lt; T &gt;()']]],
  ['getmapping',['GetMapping',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#ad748e306d3874615bf43fb74d3b1cf77',1,'SimpleSQL.SimpleSQLManager.GetMapping()'],['../class_simple_s_q_l_1_1_s_q_lite_connection.html#a7bbd9d02f7718eab3296d94efdb1dbb6',1,'SimpleSQL.SQLiteConnection.GetMapping()']]]
];
