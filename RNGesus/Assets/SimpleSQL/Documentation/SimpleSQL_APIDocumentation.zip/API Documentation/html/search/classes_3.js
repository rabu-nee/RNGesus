var searchData=
[
  ['defaultattribute',['DefaultAttribute',['../class_extra___docs_1_1_attributes_1_1_default_attribute.html',1,'Extra_Docs.Attributes.DefaultAttribute'],['../class_simple_s_q_l_1_1_default_attribute.html',1,'SimpleSQL.DefaultAttribute']]]
];
